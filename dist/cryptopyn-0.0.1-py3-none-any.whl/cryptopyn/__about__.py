# SPDX-FileCopyrightText: 2023-present Ali <safarzadehali89@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
