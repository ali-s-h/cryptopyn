# cryptopyn

[![PyPI - Version](https://img.shields.io/pypi/v/cryptopyn.svg)](https://pypi.org/project/cryptopyn)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/cryptopyn.svg)](https://pypi.org/project/cryptopyn)

-----

**Table of Contents**

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install cryptopyn
```

## License

`cryptopyn` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
